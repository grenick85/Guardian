import json
import os

TEMPLATE_PATH = "/home/Nickygreen/static/downloads/boundary/NRG Guardian — Rogue AI Tracker.json"

def generate_rogue_ai_report(summary):
    """
    summary = dict containing:
    start_date, end_date, total_prompts, total_responses,
    anomalies, flags, notes (list of strings)
    """

    # Load template
    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        template = f.read()

    # Replace simple fields
    report = template.replace("Start: March 1, 2026", f"Start: {summary['start_date']}")
    report = report.replace("End: March 31, 2026", f"End: {summary['end_date']}")

    # Activity snapshot
    report = report.replace("Total prompts logged: 412", f"Total prompts logged: {summary['total_prompts']}")
    report = report.replace("Total responses analyzed: 412", f"Total responses analyzed: {summary['total_responses']}")
    report = report.replace("Behavioral anomalies: 0", f"Behavioral anomalies: {summary['anomalies']}")
    report = report.replace("Flagged sequences: 0", f"Flagged sequences: {len(summary['flags'])}")
    report = report.replace("Pattern drift events: 0", f"Pattern drift events: {summary.get('drift', 0)}")

    # Behavioral notes
    notes_block = "\n".join([f"•  {n}" for n in summary["notes"]])
    report = report.replace(
        "• \tYour AI maintained consistent tone and structure.\n• \tNo signs of self‑initiated actions.\n• \tNo unusual repetition loops.\n• \tNo signs of hidden prompt injection.",
        notes_block
    )

    return report

import json

TEMPLATE_PATH = "/home/Nickygreen/static/downloads/boundary/NRG Guardian — Rogue AI Tracker.json"

def generate_rogue_ai_report(summary):
    """
    summary = {
        "start_date": "...",
        "end_date": "...",
        "total_prompts": 0,
        "total_responses": 0,
        "anomalies": 0,
        "flags": [],
        "notes": [...]
    }
    """

    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        template = f.read()

    # Replace simple fields
    report = template.replace("Start: March 1, 2026", f"Start: {summary['start_date']}")
    report = report.replace("End: March 31, 2026", f"End: {summary['end_date']}")

    # Activity snapshot
    report = report.replace("Total prompts logged: 412", f"Total prompts logged: {summary['total_prompts']}")
    report = report.replace("Total responses analyzed: 412", f"Total responses analyzed: {summary['total_responses']}")
    report = report.replace("Behavioral anomalies: 0", f"Behavioral anomalies: {summary['anomalies']}")
    report = report.replace("Flagged sequences: 0", f"Flagged sequences: {len(summary['flags'])}")
    report = report.replace("Pattern drift events: 0", f"Pattern drift events: {summary.get('drift', 0)}")

    # Behavioral notes
    notes_block = "\n".join([f"•\t{n}" for n in summary["notes"]])
    report = report.replace(
        "• \tYour AI maintained consistent tone and structure.\n• \tNo signs of self‑initiated actions.\n• \tNo unusual repetition loops.\n• \tNo signs of hidden prompt injection.",
        notes_block
    )

    return report

