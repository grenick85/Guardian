def generate_rogue_ai_report(data):
    """
    data = {
        "start_date": "March 1, 2026",
        "end_date": "March 31, 2026",
        "total_prompts": 412,
        "total_responses": 412,
        "anomalies": 0,
        "flags": [],
        "notes": [
            "Your AI maintained consistent tone and structure.",
            "No signs of self‑initiated actions.",
            "No unusual repetition loops.",
            "No signs of hidden prompt injection."
        ]
    }
    """

    template_path = "/home/Nickygreen/static/downloads/boundary/NRG Guardian — Rogue AI Tracker.json"

    with open(template_path, "r", encoding="utf-8") as f:
        template = f.read()

    # Replace simple fields
    report = template.replace("Start: March 1, 2026", f"Start: {data['start_date']}")
    report = report.replace("End: March 31, 2026", f"End: {data['end_date']}")

    # Replace activity snapshot
    report = report.replace("Total prompts logged: 412", f"Total prompts logged: {data['total_prompts']}")
    report = report.replace("Total responses analyzed: 412", f"Total responses analyzed: {data['total_responses']}")
    report = report.replace("Behavioral anomalies: 0", f"Behavioral anomalies: {data['anomalies']}")
    report = report.replace("Flagged sequences: 0", f"Flagged sequences: {len(data['flags'])}")
    report = report.replace("Pattern drift events: 0", f"Pattern drift events: {data.get('drift', 0)}")

    # Replace behavioral notes
    notes_block = "\n".join([f"•  {n}" for n in data["notes"]])
    report = report.replace(
        "• \tYour AI maintained consistent tone and structure.\n• \tNo signs of self‑initiated actions.\n• \tNo unusual repetition loops.\n• \tNo signs of hidden prompt injection.",
        notes_block
    )

    return report

