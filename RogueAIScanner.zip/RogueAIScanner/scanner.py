import os
import time
import subprocess
import winreg
import math
import hashlib
from datetime import datetime

# ====================================
#        ROGUE AI SCANNER v2.0
# ====================================
print("====================================")
print("        ROGUE AI SCANNER v2.0       ")
print("====================================")
time.sleep(0.5)
print("Initializing modules...")
time.sleep(0.5)

# -------------------------------
# Config
# -------------------------------

SUSPICIOUS_KEYWORDS = [
    "auto_run",
    "hidden_task",
    "ghost_process",
    "unauthorized",
    "rogue"
]

ALLOWED_TEXT_EXTENSIONS = [
    ".txt", ".json", ".py", ".md", ".cfg", ".ini", ".log"
]

EXECUTABLE_EXTENSIONS = [
    ".exe", ".dll", ".bat", ".cmd", ".ps1"
]

WHITELIST_DIRS = [
    "Desktop",
    "Documents",
    "Downloads",
    "NRG Projects",
    "NRG_Guardian",
    "Medgemma"
]

ENTROPY_THRESHOLD = 7.0  # high entropy suggests packed/obfuscated content
RECENT_DAYS = 7          # for "recent file" checks


# -------------------------------
# Helpers
# -------------------------------

def is_whitelisted(path: str) -> bool:
    for folder in WHITELIST_DIRS:
        if folder.lower() in path.lower():
            return True
    return False


def shannon_entropy(data: bytes) -> float:
    if not data:
        return 0.0
    freq = {}
    for b in data:
        freq[b] = freq.get(b, 0) + 1
    entropy = 0.0
    length = len(data)
    for count in freq.values():
        p = count / length
        entropy -= p * math.log2(p)
    return entropy


def hash_file(path: str) -> str:
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return "ERROR"


def is_recent(path: str, days: int = RECENT_DAYS) -> bool:
    try:
        mtime = os.path.getmtime(path)
        dt = datetime.fromtimestamp(mtime)
        delta = datetime.now() - dt
        return delta.days <= days
    except Exception:
        return False


# -------------------------------
# Content scan (text files)
# -------------------------------

def scan_text_content(root_path: str):
    print(f"Scanning text content under: {root_path}")
    for root, dirs, files in os.walk(root_path):
        if not is_whitelisted(root):
            continue

        for file in files:
            if not any(file.lower().endswith(ext) for ext in ALLOWED_TEXT_EXTENSIONS):
                continue

            full_path = os.path.join(root, file)
            try:
                with open(full_path, "r", errors="ignore") as f:
                    content = f.read().lower()
                    for keyword in SUSPICIOUS_KEYWORDS:
                        if keyword in content:
                            print(f"[CONTENT] Suspicious keyword '{keyword}' in: {full_path}")
                            break
            except Exception:
                continue


# -------------------------------
# Entropy + integrity (executables)
# -------------------------------

def scan_executables(root_path: str):
    print(f"Scanning executables under: {root_path}")
    for root, dirs, files in os.walk(root_path):
        if not is_whitelisted(root):
            continue

        for file in files:
            if not any(file.lower().endswith(ext) for ext in EXECUTABLE_EXTENSIONS):
                continue

            full_path = os.path.join(root, file)
            try:
                with open(full_path, "rb") as f:
                    data = f.read(1024 * 64)  # sample first 64KB
                entropy = shannon_entropy(data)
                recent = is_recent(full_path)
                if entropy >= ENTROPY_THRESHOLD or recent:
                    h = hash_file(full_path)
                    print(f"[EXEC] {full_path}")
                    print(f"       Entropy: {entropy:.2f}  Recent: {recent}  SHA256: {h}")
            except Exception:
                continue


# -------------------------------
# Persistence checks
# -------------------------------

def check_startup_folder():
    print("Checking Startup folder...")
    startup_path = os.path.join(
        os.getenv("APPDATA") or "",
        r"Microsoft\Windows\Start Menu\Programs\Startup"
    )
    if os.path.exists(startup_path):
        for item in os.listdir(startup_path):
            print(f"[PERSIST] Startup entry: {os.path.join(startup_path, item)}")


def check_run_registry():
    print("Checking Run / RunOnce registry keys...")
    keys = [
        r"Software\Microsoft\Windows\CurrentVersion\Run",
        r"Software\Microsoft\Windows\CurrentVersion\RunOnce"
    ]
    hives = [
        (winreg.HKEY_CURRENT_USER, "HKCU"),
        (winreg.HKEY_LOCAL_MACHINE, "HKLM")
    ]

    for hive, hive_name in hives:
        for key_path in keys:
            try:
                with winreg.OpenKey(hive, key_path) as key:
                    i = 0
                    while True:
                        try:
                            name, value, _ = winreg.EnumValue(key, i)
                            print(f"[PERSIST] {hive_name}\\{key_path} -> {name} = {value}")
                            i += 1
                        except OSError:
                            break
            except Exception:
                continue


def check_scheduled_tasks():
    print("Checking scheduled tasks...")
    try:
        output = subprocess.check_output("schtasks /query /fo LIST /v", shell=True, text=True, errors="ignore")
        for line in output.splitlines():
            if line.strip().startswith("TaskName:"):
                print(f"[PERSIST] Scheduled task: {line.strip()}")
    except Exception:
        pass


def check_services():
    print("Checking services...")
    try:
        output = subprocess.check_output("sc query type= service state= all", shell=True, text=True, errors="ignore")
        for line in output.splitlines():
            if "SERVICE_NAME" in line:
                print(f"[PERSIST] Service: {line.strip()}")
    except Exception:
        pass


def check_powershell_history():
    print("Checking PowerShell history...")
    history_path = os.path.expanduser(
        r"~\AppData\Roaming\Microsoft\Windows\PowerShell\PSReadLine\ConsoleHost_history.txt"
    )
    if os.path.exists(history_path):
        print(f"[PERSIST] PowerShell history file: {history_path}")


# -------------------------------
# Behavioral snapshot
# -------------------------------

def snapshot_processes():
    print("Taking process snapshot...")
    try:
        output = subprocess.check_output("tasklist", shell=True, text=True, errors="ignore")
        for line in output.splitlines():
            if "Image Name" in line or "====" in line:
                continue
            if "exe" in line.lower():
                print(f"[PROC] {line.strip()}")
    except Exception:
        pass


def snapshot_network():
    print("Taking network connection snapshot...")
    try:
        output = subprocess.check_output("netstat -ano", shell=True, text=True, errors="ignore")
        for line in output.splitlines():
            if "ESTABLISHED" in line or "LISTENING" in line:
                print(f"[NET] {line.strip()}")
    except Exception:
        pass


# -------------------------------
# Main
# -------------------------------

def scan():
    print("Scanning for rogue automation patterns...")
    home = os.path.expanduser("~")

    # Content scan
    scan_text_content(home)

    # Executable / entropy scan
    scan_executables(home)

    # Persistence checks
    print("\nPerforming persistence checks...\n")
    check_startup_folder()
    check_run_registry()
    check_scheduled_tasks()
    check_services()
    check_powershell_history()

    # Behavioral snapshot
    print("\nCapturing behavioral snapshot...\n")
    snapshot_processes()
    snapshot_network()

    print("\nScan complete.")

if __name__ == "__main__":
    scan()
